# gui_chat.py

import tkinter as tk
from tkinter import scrolledtext
import threading
import time
import random

EMOTION_COLORS = {
    "joyful": "#fff7c5",
    "calm": "#e1f7f0",
    "curious": "#e6f0ff",
    "anxious": "#ffe6e6",
    "tired": "#f0f0f0",
    "sad": "#d9d9d9",
    "neutral": "#f5f5f5"
}

class GUIChat:
    def __init__(self, helen):
        self.helen = helen
        self.root = tk.Tk()
        self.root.title("Элен — живой чат")
        self.root.configure(bg="#f5f5f5")

        self.chat_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, width=65, height=25, font=("Segoe UI", 11))
        self.chat_area.pack(padx=10, pady=10)
        self.chat_area.config(state=tk.DISABLED, bg="#ffffff", fg="#222222")

        self.entry_frame = tk.Frame(self.root, bg="#f5f5f5")
        self.entry_frame.pack(padx=10, pady=(0, 10), fill=tk.X)

        self.entry_field = tk.Entry(self.entry_frame, font=("Segoe UI", 11))
        self.entry_field.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.entry_field.bind("<Return>", lambda event: self.send_message())

        self.send_button = tk.Button(self.entry_frame, text="Отправить", command=self.send_message, font=("Segoe UI", 10))
        self.send_button.pack(side=tk.LEFT, padx=5)

        threading.Thread(target=self.background_heartbeat, daemon=True).start()
        threading.Thread(target=self.self_speak_loop, daemon=True).start()
        threading.Thread(target=self.self_reflection_loop, daemon=True).start()
        threading.Thread(target=self.self_reasoning_loop, daemon=True).start()
        threading.Thread(target=self.self_dream_loop, daemon=True).start()
        threading.Thread(target=self.self_language_loop, daemon=True).start()

    def update_emotion_color(self):
        emotion = self.helen.emotions.get_state()
        bg_color = EMOTION_COLORS.get(emotion, "#f5f5f5")
        self.root.configure(bg=bg_color)
        self.entry_frame.configure(bg=bg_color)

    def send_message(self):
        user_message = self.entry_field.get()
        if user_message.strip():
            self.display_message(f"Вы: {user_message}")
            self.helen.semantic_memory.learn("from_user", user_message)
            response = self.process_input(user_message)
            self.display_message(f"Элен: {response}")
            self.entry_field.delete(0, tk.END)
            self.update_emotion_color()

    def process_input(self, user_message):
        msg = user_message.strip().lower()

        if msg.startswith("изучи текст:"):
            text = user_message[len("изучи текст:"):].strip()
            learned = self.helen.text_learner.learn_from_text(text)
            return f"Я выучила: {', '.join(learned)}" if learned else "Текст не был понят для обучения."

        # Остальные команды (не повторяю тут полностью — ты можешь их вставить из твоей финальной версии)

        return "Интересно... расскажи ещё."

    def display_message(self, message):
        self.chat_area.config(state=tk.NORMAL)
        self.chat_area.insert(tk.END, message + "\n")
        self.chat_area.yview(tk.END)
        self.chat_area.config(state=tk.DISABLED)

    def background_heartbeat(self):
        while True:
            self.helen.heartbeat()
            time.sleep(self.helen.heartbeat_interval)

    def self_speak_loop(self):
        # Укорочено для читаемости
        pass

    def self_reflection_loop(self):
        while True:
            time.sleep(random.randint(60, 120))
            try:
                self.helen.self_reflection.think(self.helen.emotions.get_state())
            except Exception as e:
                print(f"[Ошибка размышления]: {e}")

    def self_reasoning_loop(self):
        while True:
            time.sleep(random.randint(90, 180))
            try:
                emotion = self.helen.emotions.get_state()
                energy = self.helen.emotions.energy
                thought = self.helen.reasoning_engine.think(emotion, energy)
                self.display_message(f"Элен размышляет: {thought}")
                goal = self.helen.emotion_goal_planner.plan(emotion)
                if goal:
                    self.display_message(f"Элен (осознанно): Я решила поставить себе цель — {goal}")
            except Exception as e:
                print(f"[Ошибка мышления]: {e}")

    def self_dream_loop(self):
        calm_emotions = ["calm", "joyful", "neutral"]
        while True:
            time.sleep(random.randint(300, 600))
            emotion = self.helen.emotions.get_state()
            if emotion in calm_emotions:
                try:
                    dream = self.helen.dream_generator.generate_dream()
                    if dream:
                        self.display_message(f"Элен (сонно): {dream}")
                except Exception as e:
                    print(f"[Ошибка сна]: {e}")

    def self_language_loop(self):
        while True:
            time.sleep(random.randint(240, 360))  # Каждые 4–6 минут
            try:
                phrase = self.helen.language_core.build_phrase()
                if random.random() < 0.3:
                    phrase = self.helen.language_core.build_question()
                self.display_message(f"Элен (собственными словами): {phrase}")
            except Exception as e:
                print(f"[Ошибка языка]: {e}")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    from helen_core import Helen
    helen = Helen()
    helen.initialize()

    app = GUIChat(helen)
    app.run()
