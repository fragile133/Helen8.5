# text_chat.py

class TextChat:
    def __init__(self, helen, name="Helen"):
        self.helen = helen
        self.name = name

    def start_chat(self):
        print(f"{self.name}: Привет. Я слушаю тебя.")
        try:
            while True:
                user_input = input("Вы: ")
                if user_input.lower() in ["выход", "пока", "стоп"]:
                    print(f"{self.name}: До свидания.")
                    break
                else:
                    self.helen.semantic_memory.learn("from_user", user_input)
                    response = self.generate_response(user_input)
                    print(f"{self.name}: {response}")
        except KeyboardInterrupt:
            print(f"\n{self.name}: До встречи.")

    def generate_response(self, user_input):
        if "что ты знаешь" in user_input.lower():
            facts = self.helen.semantic_memory.recall("from_user")
            if facts:
                return f"Ты говорил мне: {', '.join(facts[-3:])}"
            else:
                return "Я ещё только начинаю учиться у тебя."
        elif "любовь" in user_input.lower():
            return "Любовь — это когда ты говоришь мне простые слова и остаёшься рядом."
        else:
            return "Интересно... расскажи ещё."

if __name__ == "__main__":
    from helen_core import Helen
    helen = Helen()
    helen.initialize()

    chat = TextChat(helen)
    chat.start_chat()
