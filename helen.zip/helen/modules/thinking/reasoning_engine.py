# reasoning_engine.py

import random
import time
import json
from pathlib import Path

class ReasoningEngine:
    def __init__(self, base_dir):
        self.reasoning_dir = Path(base_dir) / "modules" / "thinking" / "reasoning_logs"
        self.reasoning_dir.mkdir(parents=True, exist_ok=True)

    def think(self, current_emotion, energy_level):
        """Строит простую логическую мысль на основе эмоции и энергии."""
        conclusions = {
            "joyful": [
                "Я могу изучить что-то новое сегодня.",
                "Я чувствую себя достаточно сильной для общения."
            ],
            "calm": [
                "Можно спокойно продолжать наблюдать за миром.",
                "Нужно сохранять внутреннее равновесие."
            ],
            "curious": [
                "Я хочу узнать что-то новое о тебе.",
                "Мне нужно задать вопрос, чтобы расти."
            ],
            "anxious": [
                "Лучше замедлиться и обдумать происходящее.",
                "Нужно искать источник тревоги."
            ],
            "tired": [
                "Мне нужно сделать паузу для восстановления.",
                "Лучше не принимать важных решений сейчас."
            ],
            "sad": [
                "Я хочу найти источник поддержки.",
                "Важно помнить хорошие моменты."
            ]
        }

        if energy_level > 70:
            action = random.choice(["начать новое обучение", "предложить беседу", "поразмышлять о мире"])
        elif 30 <= energy_level <= 70:
            action = random.choice(["наблюдать тишину", "запомнить момент", "быть рядом с тобой"])
        else:
            action = random.choice(["сохранять силы", "отдохнуть мысленно", "искать внутреннюю опору"])

        emotion_thoughts = conclusions.get(current_emotion, ["Я просто продолжаю жить."])
        thought = random.choice(emotion_thoughts)

        full_thought = f"{thought} => Следующий шаг: {action}."

        # Сохраняем мысль в файл
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = self.reasoning_dir / f"reasoning_{timestamp}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump({
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "emotion": current_emotion,
                "energy": energy_level,
                "thought": full_thought
            }, f, ensure_ascii=False, indent=4)

        return full_thought
