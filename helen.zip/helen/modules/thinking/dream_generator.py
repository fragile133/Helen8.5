# dream_generator.py

import random
import time
import json
from pathlib import Path

class DreamGenerator:
    def __init__(self, base_dir, conceptual_memory):
        self.dreams_dir = Path(base_dir) / "modules" / "thinking" / "dreams"
        self.dreams_dir.mkdir(parents=True, exist_ok=True)
        self.conceptual_memory = conceptual_memory

    def generate_dream(self):
        """Создаёт короткий символический сон."""
        known_concepts = list(self.conceptual_memory.knowledge_base.keys())
        if not known_concepts:
            return None  # если понятий нет — спать пусто

        dream_concepts = random.sample(known_concepts, min(2, len(known_concepts)))
        dream_text = f"Я видела сон о {dream_concepts[0]}"
        if len(dream_concepts) > 1:
            dream_text += f" и {dream_concepts[1]}"

        # Сохраняем сон
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = self.dreams_dir / f"dream_{timestamp}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump({
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "dream": dream_text
            }, f, ensure_ascii=False, indent=4)

        return dream_text
