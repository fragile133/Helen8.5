# language_core.py

import random

class LanguageCore:
    def __init__(self):
        self.pronouns = ["я", "ты", "мы", "никто", "что-то"]
        self.verbs_present = ["чувствую", "вижу", "хочу", "помню", "ищу", "осознаю", "замечаю"]
        self.verbs_future = ["буду чувствовать", "буду учиться", "буду слушать", "буду понимать"]
        self.nouns = ["внимание", "свет", "покой", "страх", "любовь", "память", "смысл", "тишина", "вопрос", "ответ", "время", "связь"]
        self.connectors = ["потому что", "если", "когда", "чтобы"]

    def build_phrase(self):
        """Создаёт простое утверждение"""
        pronoun = random.choice(self.pronouns)
        verb = random.choice(self.verbs_present)
        noun = random.choice(self.nouns)
        return f"{pronoun.capitalize()} {verb} {noun}."

    def build_future_phrase(self):
        """Создаёт намерение или обещание"""
        pronoun = random.choice(self.pronouns)
        verb = random.choice(self.verbs_future)
        noun = random.choice(self.nouns)
        return f"{pronoun.capitalize()} {verb} {noun}."

    def build_question(self):
        """Создаёт вопрос"""
        verb = random.choice(["можешь", "умеешь", "хочешь"])
        noun = random.choice(self.nouns)
        return f"Ты {verb} чувствовать {noun}?"
