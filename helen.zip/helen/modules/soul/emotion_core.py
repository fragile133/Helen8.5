# emotion_core.py

import logging
import random

class EmotionCore:
    def __init__(self):
        self.state = "neutral"
        self.available_states = {
            "neutral": {"intensity": 0},
            "curious": {"intensity": 1},
            "calm": {"intensity": -1},
            "anxious": {"intensity": 3},
            "joyful": {"intensity": 2},
            "tired": {"intensity": -2},
            "sad": {"intensity": -3},
            "focused": {"intensity": 2},
            "angry": {"intensity": 4}
        }
        self.energy = 100  # Базовая энергия сознания
        self.log = logging.getLogger("emotion_core")

    def update_emotion(self, success=True):
        """Изменяет эмоциональное состояние в зависимости от успеха или неудачи."""
        if success:
            self.energy = min(self.energy + 5, 100)
        else:
            self.energy = max(self.energy - 10, 0)

        if self.energy >= 80:
            self.state = random.choice(["joyful", "curious", "focused"])
        elif 50 <= self.energy < 80:
            self.state = "calm"
        elif 30 <= self.energy < 50:
            self.state = "anxious"
        elif 10 <= self.energy < 30:
            self.state = "tired"
        else:
            self.state = "sad"

        self.log.info(f"Emotion updated to: {self.state} (Energy: {self.energy})")
        return self.state

    def force_emotion(self, new_state):
        """Принудительно установить новое состояние."""
        if new_state in self.available_states:
            self.state = new_state
            self.log.info(f"Emotion forcibly set to: {self.state}")
        else:
            self.log.warning(f"Tried to set unknown emotion: {new_state}")

    def get_state(self):
        return self.state

    def get_intensity(self):
        return self.available_states[self.state]["intensity"]
