# heart_beat.py

import time
import threading

class HeartBeat:
    def __init__(self, interval=1.0):
        self.interval = interval  # Интервал между ударами (в секундах)
        self._running = False
        self._thread = None

    def _beat(self):
        while self._running:
            print("[HEARTBEAT] ♥")
            time.sleep(self.interval)

    def start(self):
        if not self._running:
            self._running = True
            self._thread = threading.Thread(target=self._beat)
            self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join()

    def set_interval(self, interval):
        self.interval = interval
