# text_learner.py

import re

class TextLearner:
    def __init__(self, conceptual_memory):
        self.conceptual_memory = conceptual_memory

    def learn_from_text(self, text):
        """Учится новым понятиям из простого текста."""
        sentences = re.split(r'[.!?]', text)
        learned_concepts = []

        for sentence in sentences:
            parts = sentence.split(" — ")
            if len(parts) == 2:
                word = parts[0].strip().lower()
                description = parts[1].strip().capitalize()
                self.conceptual_memory.learn_concept(word, description, links=[], emotion="neutral")
                learned_concepts.append(word)

        return learned_concepts
