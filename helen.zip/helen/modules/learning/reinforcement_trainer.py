# reinforcement_trainer.py

class ReinforcementTrainer:
    def __init__(self, base_dir):
        self.experiences = []
        # Мы больше не сохраняем в training_data

    def add_experience(self, state, action, reward):
        """Сохраняет опыт только в памяти (в RAM), не в файл."""
        experience = {
            "state": state,
            "action": action,
            "reward": reward
        }
        self.experiences.append(experience)

    def suggest_action(self, current_state):
        """Пока возвращает всегда 'heartbeat' — заглушка."""
        return "heartbeat"
