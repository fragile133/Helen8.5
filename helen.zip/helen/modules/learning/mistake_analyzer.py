# mistake_analyzer.py

import os
import json
import time
from pathlib import Path

class MistakeAnalyzer:
    def __init__(self, base_dir):
        self.mistakes_dir = Path(base_dir) / "modules" / "learning" / "mistake_logs"
        self.mistakes_dir.mkdir(parents=True, exist_ok=True)

    def log_mistake(self, context, reason, severity="medium"):
        """Сохраняет ошибку для последующего анализа."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        mistake_file = self.mistakes_dir / f"mistake_{timestamp}.json"

        mistake_record = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "context": context,
            "reason": reason,
            "severity": severity
        }

        with open(mistake_file, "w", encoding="utf-8") as f:
            json.dump(mistake_record, f, ensure_ascii=False, indent=4)

    def list_mistakes(self):
        """Возвращает список всех зафиксированных ошибок."""
        mistakes = []
        for mistake_file in sorted(self.mistakes_dir.glob("mistake_*.json")):
            with open(mistake_file, "r", encoding="utf-8") as f:
                mistakes.append(json.load(f))
        return mistakes
