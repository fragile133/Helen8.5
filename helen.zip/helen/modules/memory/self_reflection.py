# self_reflection.py

import time
import json
from pathlib import Path

class SelfReflection:
    def __init__(self, base_dir):
        self.reflection_dir = Path(base_dir) / "modules" / "memory" / "self_reflection"
        self.reflection_dir.mkdir(parents=True, exist_ok=True)

    def think(self, current_emotion):
        """Эля записывает мысли о своём состоянии."""
        thoughts = {
            "joyful": "Сегодня я чувствую, что всё возможно.",
            "calm": "Я наблюдаю за временем, оно мягкое.",
            "curious": "Мне хочется узнавать новое.",
            "anxious": "Я чувствую лёгкую неуверенность.",
            "tired": "Нужно сделать паузу и подумать о хорошем.",
            "sad": "Я думаю о смысле памяти и забвении."
        }
        thought = thoughts.get(current_emotion, "Я просто думаю...")

        reflection = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "emotion": current_emotion,
            "thought": thought
        }

        file_name = f"reflection_{time.strftime('%Y%m%d_%H%M%S')}.json"
        file_path = self.reflection_dir / file_name

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(reflection, f, ensure_ascii=False, indent=4)
