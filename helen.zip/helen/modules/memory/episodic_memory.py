# episodic_memory.py

import os
import json
import time
from pathlib import Path

class EpisodicMemory:
    def __init__(self, base_dir):
        self.memory_dir = Path(base_dir) / "modules" / "memory" / "episodic_storage"
        self.memory_dir.mkdir(parents=True, exist_ok=True)

    def remember(self, data):
        """Сохраняет событие в память."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        memory_file = self.memory_dir / f"memory_{timestamp}.json"

        with open(memory_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    def recall_last(self):
        """Вспоминает последнее событие."""
        memories = sorted(self.memory_dir.glob("memory_*.json"), reverse=True)
        if memories:
            with open(memories[0], "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            return None

    def recall_all(self):
        """Вспоминает всё, что было сохранено."""
        all_memories = []
        for memory_file in sorted(self.memory_dir.glob("memory_*.json")):
            with open(memory_file, "r", encoding="utf-8") as f:
                all_memories.append(json.load(f))
        return all_memories
