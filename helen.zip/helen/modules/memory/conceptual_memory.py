# conceptual_memory.py

import json
from pathlib import Path

class ConceptualMemory:
    def __init__(self, base_dir):
        self.knowledge_file = Path(base_dir) / "modules" / "memory" / "word_knowledge.json"
        if not self.knowledge_file.exists():
            self._initialize_knowledge_base()
        self.knowledge_base = self._load_knowledge()

    def _initialize_knowledge_base(self):
        initial_data = {
            "любовь": {
                "описание": "Тёплое чувство заботы о другом существе.",
                "связи": ["забота", "радость", "доверие"],
                "эмоция": "joyful"
            }
        }
        with open(self.knowledge_file, "w", encoding="utf-8") as f:
            json.dump(initial_data, f, ensure_ascii=False, indent=4)

    def _load_knowledge(self):
        with open(self.knowledge_file, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_knowledge(self):
        with open(self.knowledge_file, "w", encoding="utf-8") as f:
            json.dump(self.knowledge_base, f, ensure_ascii=False, indent=4)

    def learn_concept(self, word, description, links=None, emotion="neutral"):
        """Добавить или обновить понятие."""
        if links is None:
            links = []
        self.knowledge_base[word] = {
            "описание": description,
            "связи": links,
            "эмоция": emotion
        }
        self.save_knowledge()

    def recall_concept(self, word):
        """Вернуть понятие, если оно есть."""
        return self.knowledge_base.get(word, None)

    def find_related(self, word):
        """Найти связанные понятия."""
        concept = self.knowledge_base.get(word, {})
        return concept.get("связи", [])
