# semantic_memory.py

import os
import json
from pathlib import Path

class SemanticMemory:
    def __init__(self, base_dir):
        self.memory_dir = Path(base_dir) / "modules" / "memory" / "semantic_storage"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.knowledge_base = {}

    def learn(self, topic, fact):
        """Сохраняет фразу по теме."""
        if topic not in self.knowledge_base:
            self._load_topic(topic)
        if fact not in self.knowledge_base[topic]:
            self.knowledge_base[topic].append(fact)
            self._save_topic(topic)

    def recall(self, topic):
        """Возвращает список фраз по теме."""
        if topic not in self.knowledge_base:
            self._load_topic(topic)
        return self.knowledge_base.get(topic, [])

    def _save_topic(self, topic):
        topic_file = self.memory_dir / f"{topic}.json"
        with open(topic_file, "w", encoding="utf-8") as f:
            json.dump(self.knowledge_base[topic], f, ensure_ascii=False, indent=2)

    def _load_topic(self, topic):
        topic_file = self.memory_dir / f"{topic}.json"
        if topic_file.exists():
            with open(topic_file, "r", encoding="utf-8") as f:
                self.knowledge_base[topic] = json.load(f)
        else:
            self.knowledge_base[topic] = []
