# conceptual_links.py

class ConceptualLinks:
    def __init__(self, conceptual_memory):
        self.conceptual_memory = conceptual_memory

    def find_related_concepts(self, word):
        """Находит связанные понятия, если они есть."""
        concept = self.conceptual_memory.recall_concept(word)
        if not concept:
            return []

        links = concept.get("связи", [])
        related_info = []
        for linked_word in links:
            linked_concept = self.conceptual_memory.recall_concept(linked_word)
            if linked_concept:
                related_info.append({
                    "слово": linked_word,
                    "описание": linked_concept["описание"]
                })

        return related_info
