# success_memory.py

import json
import time
from pathlib import Path

class SuccessMemory:
    def __init__(self, base_dir):
        self.success_file = Path(base_dir) / "modules" / "memory" / "success_log.json"
        if not self.success_file.exists():
            with open(self.success_file, "w", encoding="utf-8") as f:
                json.dump([], f, ensure_ascii=False, indent=2)

    def log_success(self, goal_description):
        """Добавляет выполненную цель в журнал успехов."""
        entry = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "goal": goal_description
        }
        success_list = self._load_all()
        success_list.append(entry)
        with open(self.success_file, "w", encoding="utf-8") as f:
            json.dump(success_list, f, ensure_ascii=False, indent=2)

    def _load_all(self):
        with open(self.success_file, "r", encoding="utf-8") as f:
            return json.load(f)

    def get_last_successes(self, count=3):
        return self._load_all()[-count:]
