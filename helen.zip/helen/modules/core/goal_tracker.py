# goal_tracker.py

class GoalTracker:
    def __init__(self, goal_manager):
        self.goal_manager = goal_manager

    def evaluate_goals(self, message):
        """Проверяет, выполняется ли какая-либо цель на основе текста сообщения."""
        completed_goals = []
        for goal in self.goal_manager.list_goals():
            if goal["description"].lower() in message.lower():
                result = self.goal_manager.complete_goal(goal["description"])
                if result:
                    completed_goals.append(result["description"])
        return completed_goals
