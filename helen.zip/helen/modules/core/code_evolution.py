# TODO: Модуль core.
