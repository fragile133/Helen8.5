# goal_manager.py

import time
import json
from pathlib import Path

class GoalManager:
    def __init__(self, base_dir):
        self.goals_dir = Path(base_dir) / "modules" / "core" / "goals"
        self.goals_dir.mkdir(parents=True, exist_ok=True)
        self.goals = []
        self._load_goals()

    def _load_goals(self):
        """Загружает все цели из файлов."""
        for file in self.goals_dir.glob("goal_*.json"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    goal = json.load(f)
                    self.goals.append(goal)
            except Exception as e:
                print(f"[Ошибка загрузки цели]: {e}")

    def create_goal(self, description, reason=None):
        """Создаёт новую цель и сохраняет её в файл."""
        goal = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "description": description,
            "reason": reason or "без причины",
            "completed": False
        }
        self.goals.append(goal)
        self._save_goal(goal)
        return goal

    def _save_goal(self, goal):
        """Сохраняет цель в файл."""
        safe_name = goal["description"].replace(" ", "_").replace("\"", "").replace("'", "").lower()
        filename = f"goal_{safe_name}.json"
        filepath = self.goals_dir / filename
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(goal, f, ensure_ascii=False, indent=4)

    def list_goals(self):
        """Возвращает список всех активных целей."""
        return [g for g in self.goals if not g["completed"]]

    def complete_goal(self, description):
        """Отмечает цель как выполненную и сохраняет изменения."""
        for goal in self.goals:
            if goal["description"].lower() == description.lower() and not goal["completed"]:
                goal["completed"] = True
                self._save_goal(goal)
                return goal
        return None
