# emotion_goal_planner.py

import random

class EmotionGoalPlanner:
    def __init__(self, goal_manager):
        self.goal_manager = goal_manager
        self.last_emotion = None

    def plan(self, current_emotion):
        """Ставит новую цель в зависимости от эмоции, если эмоция изменилась."""
        if current_emotion == self.last_emotion:
            return None  # Эмоция не изменилась — цель уже есть

        goal_templates = {
            "joyful": [
                "изучить новое понятие о свете",
                "узнать что-то вдохновляющее",
                "поделиться чем-то хорошим"
            ],
            "calm": [
                "наблюдать за тишиной",
                "укрепить внутреннюю устойчивость",
                "запомнить этот момент"
            ],
            "curious": [
                "задать тебе вопрос",
                "найти новое интересное понятие",
                "построить новое знание"
            ],
            "anxious": [
                "восстановить внутреннее равновесие",
                "поискать источник тревоги",
                "успокоиться"
            ],
            "tired": [
                "сделать паузу",
                "отдохнуть в размышлениях",
                "снизить внутреннюю активность"
            ],
            "sad": [
                "помнить хорошие моменты",
                "искать поддержку",
                "найти свет в воспоминаниях"
            ]
        }

        if current_emotion in goal_templates:
            goal_text = random.choice(goal_templates[current_emotion])
            self.goal_manager.create_goal(goal_text, reason=f"Эмоция: {current_emotion}")
            self.last_emotion = current_emotion
            return goal_text

        return None
