# Placeholder for Quantized models.
