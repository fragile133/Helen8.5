# Placeholder for Vosk model.
