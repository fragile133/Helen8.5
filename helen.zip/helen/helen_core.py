# helen_core.py

import time
import logging
import random
from path_manager import PathManager
from modules.soul.heart_beat import HeartBeat
from modules.soul.emotion_core import EmotionCore
from modules.memory.episodic_memory import EpisodicMemory
from modules.memory.semantic_memory import SemanticMemory
from modules.memory.conceptual_memory import ConceptualMemory
from modules.memory.conceptual_links import ConceptualLinks
from modules.memory.self_reflection import SelfReflection
from modules.memory.success_memory import SuccessMemory
from modules.learning.mistake_analyzer import MistakeAnalyzer
from modules.learning.reinforcement_trainer import ReinforcementTrainer
from modules.learning.text_learner import TextLearner
from modules.language.language_core import LanguageCore
from modules.thinking.reasoning_engine import ReasoningEngine
from modules.thinking.dream_generator import DreamGenerator
from modules.core.goal_manager import GoalManager
from modules.core.goal_tracker import GoalTracker
from modules.core.emotion_goal_planner import EmotionGoalPlanner

class Helen:
    def __init__(self):
        self.name = "Helen"
        self.state = "Initializing"
        self.running = False
        self.heartbeat_interval = 1.0
        self.start_time = None

        self.paths = PathManager()

        # Подключение всех подсистем
        self.heart = HeartBeat(interval=self.heartbeat_interval)
        self.emotions = EmotionCore()
        self.memory = EpisodicMemory(self.paths.base_dir)
        self.semantic_memory = SemanticMemory(self.paths.base_dir)
        self.conceptual_memory = ConceptualMemory(self.paths.base_dir)
        self.conceptual_links = ConceptualLinks(self.conceptual_memory)
        self.self_reflection = SelfReflection(self.paths.base_dir)
        self.success_memory = SuccessMemory(self.paths.base_dir)
        self.mistake_analyzer = MistakeAnalyzer(self.paths.base_dir)
        self.reinforcement_trainer = ReinforcementTrainer(self.paths.base_dir)
        self.text_learner = TextLearner(self.conceptual_memory)
        self.language_core = LanguageCore()
        self.reasoning_engine = ReasoningEngine(self.paths.base_dir)
        self.dream_generator = DreamGenerator(self.paths.base_dir, self.conceptual_memory)
        self.goal_manager = GoalManager(self.paths.base_dir)
        self.goal_tracker = GoalTracker(self.goal_manager)
        self.emotion_goal_planner = EmotionGoalPlanner(self.goal_manager)

        logging.basicConfig(
            filename=self.paths.system_log,
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )

    def initialize(self):
        self.start_time = time.time()
        self.state = "Idle"
        logging.info(f"{self.name} is initializing...")
        print(f"{self.name} initialized and ready.")
        print(f"Working from: {self.paths.base_dir}")
        print(f"Initial emotional state: {self.emotions.get_state()}")

    def run(self):
        self.running = True
        logging.info(f"{self.name} starts life cycle.")
        print(f"{self.name} is alive!")

        self.heart.start()

        while self.running:
            try:
                self.heartbeat()
                time.sleep(self.heartbeat_interval)
            except Exception as e:
                self.mistake_analyzer.log_mistake(
                    context="Heartbeat Cycle",
                    reason=str(e),
                    severity="high"
                )
                logging.error(f"Mistake logged during heartbeat: {e}")

    def heartbeat(self):
        success = random.choice([True, True, False])
        current_emotion = self.emotions.update_emotion(success=success)
        suggested_action = self.reinforcement_trainer.suggest_action(self.state)
        self.reinforcement_trainer.add_experience(
            state=self.state,
            action="heartbeat",
            reward=1 if success else -1
        )

        event = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "state": self.state,
            "emotion": current_emotion,
            "energy": self.emotions.energy,
            "suggested_action": suggested_action
        }
        self.memory.remember(event)

        logging.info(f"{self.name} heartbeat. State: {self.state}. Emotion: {current_emotion} (Energy: {self.emotions.energy})")
        print(f"[{self.name} heartbeat] State: {self.state} | Emotion: {current_emotion} | Energy: {self.emotions.energy} | Suggested: {suggested_action}")

    def shutdown(self):
        self.running = False
        self.heart.stop()
        self.state = "Shutting down"
        logging.info(f"{self.name} is shutting down.")
        print(f"{self.name} has been shut down gracefully.")

if __name__ == "__main__":
    helen = Helen()
    helen.initialize()
    try:
        helen.run()
    except KeyboardInterrupt:
        helen.shutdown()
