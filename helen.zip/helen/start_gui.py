# start_gui.py

from helen_core import Helen
from modules.interfaces.gui_chat import GUIChat

if __name__ == "__main__":
    helen = Helen()
    helen.initialize()

    app = GUIChat(helen)
    app.run()
