# path_manager.py

import os
from pathlib import Path

class PathManager:
    def __init__(self):
        self.base_dir = Path(__file__).resolve().parent

        # Основные папки
        self.config_dir = self.base_dir / "config"
        self.models_dir = self.base_dir / "models"
        self.logs_dir = self.base_dir / "logs"
        self.modules_dir = self.base_dir / "modules"
        self.memory_dir = self.base_dir / "modules" / "memory"
        self.security_dir = self.base_dir / "modules" / "security"
        self.learning_dir = self.base_dir / "modules" / "learning"
        self.social_dir = self.base_dir / "modules" / "social"
        self.interface_dir = self.base_dir / "modules" / "interfaces"
        self.docs_dir = self.base_dir / "docs"

        # Важные файлы
        self.system_log = self.logs_dir / "system.log"
        self.config_file = self.config_dir / "main.ini"

    def resolve_all(self):
        """Вывод всех путей для отладки."""
        print("Base directory:", self.base_dir)
        print("Logs:", self.logs_dir)
        print("Config:", self.config_dir)
        print("Models:", self.models_dir)
        print("Docs:", self.docs_dir)

# Для тестирования
if __name__ == "__main__":
    pm = PathManager()
    pm.resolve_all()
